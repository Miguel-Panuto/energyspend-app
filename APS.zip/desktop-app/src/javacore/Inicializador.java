package javacore;

import javacore.view.LoginScreen;

public class Inicializador {
    public static void main(String[] args)
    {
        new LoginScreen();
    }
}
